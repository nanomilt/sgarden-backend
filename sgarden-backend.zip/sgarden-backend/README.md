The backend of SGarden platform

## Prerequisites

- node >=16

## Install

```sh
$ npm i
```

## Usage

```sh
$ npm start
```

## Run tests

```sh
$ npm test
```

## Development

```sh
$ npm run dev
```
